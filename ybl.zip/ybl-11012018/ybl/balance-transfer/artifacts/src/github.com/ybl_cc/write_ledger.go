/*
Licensed to the Apache Software Company (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding  ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
*/

package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

// ============================================================================================================================
// write() - genric write variable into ledger
//
// Shows Off PutState() - writting a key/value into the ledger
//
// Inputs - Array of strings
//    0   ,    1
//   key  ,  value
//  "abc" , "test"
// ============================================================================================================================
func write(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var key, value string
	var err error
	fmt.Println("starting write")

	if len(args) != 3 {
		return shim.Error("Incorrect number of arguments. Expecting 2. key of the variable and value to set")
	}

	// input sanitation
	err = sanitize_arguments(args)
	if err != nil {
		return shim.Error(err.Error())
	}

	key = args[1] //rename for funsies
	value = args[2]
	err = stub.PutState(key, []byte(value)) //write the variable into the ledger
	if err != nil {
		return shim.Error(err.Error())
	}

	fmt.Println("- end write")
	return shim.Success(nil)
}

// ============================================================================================================================
// delete_invoice() - remove a invoice from state and from project index
//
// Shows Off DelState() - "removing"" a key/value from the ledger
//
// Inputs - Array of strings
//      0      ,         1
//     id      ,  authed_by_company
// "m999999999", "united projects"
// ============================================================================================================================
func delete_invoice(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("starting delete_invoice")

	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	// input sanitation
	err := sanitize_arguments(args)
	if err != nil {
		return shim.Error(err.Error())
	}

	id := args[1]
	//authed_by_company := args[2]

	// get the invoice
	invoice, err := get_invoice(stub, id)
	if err != nil {
		fmt.Println("Failed to find invoice by id " + id)
		return shim.Error(err.Error())
	}

	certname, err := get_cert(stub)
	if err != nil {
		fmt.Printf("INVOKE: Error retrieving cert: %s", err)
		return shim.Error("Error retrieving cert")
	}

	anchor, err := get_lender(stub, string(certname))
	if err != nil {
		fmt.Println("Failed to find anchor user by id " + string(certname))
		return shim.Error(err.Error())
	}

	// check authorizing company (see note in set_owner() about how this is quirky)
	if invoice.Company != anchor.AnchorCompany {
		return shim.Error("The company '" + anchor.AnchorCompany + "' cannot authorize delete for '" + invoice.Company + "'.")
	}

	// remove the invoice
	err = stub.DelState(id) //remove the key from chaincode state
	if err != nil {
		return shim.Error("Failed to delete state")
	}

	fmt.Println("- end delete_invoice")
	return shim.Success(nil)
}

// ============================================================================================================================
// update_invoice_field() - remove a project from state and from project index
//
// Shows Off DelState() - "removing"" a key/value from the ledger
//
// Inputs - Array of strings
//      0      ,         1
//     id      ,  authed_by_company
// "m999999999", "united projects"
// ============================================================================================================================
func update_invoice_field(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("starting update_invoice_field")

	if len(args) != 4 {
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}

	// input sanitation
	err := sanitize_arguments(args)
	if err != nil {
		return shim.Error(err.Error())
	}

	id := args[1]

	// get the invoice
	invoice, err := get_invoice(stub, id)
	if err != nil {
		fmt.Println("Failed to find invoice by id " + id)
		return shim.Error(err.Error())
	}

	certname, err := get_cert(stub)
	if err != nil {
		fmt.Printf("INVOKE: Error retrieving cert: %s", err)
		return shim.Error("Error retrieving cert")
	}

	anchor, err := get_lender(stub, string(certname))
	if err != nil {
		fmt.Println("Failed to find anchor user by id " + string(certname))
		return shim.Error(err.Error())
	}

	// check authorizing company (see note in set_owner() about how this is quirky)
	if invoice.Company != anchor.AnchorCompany {
		return shim.Error("The company '" + anchor.AnchorCompany + "' cannot authorize delete for '" + invoice.Company + "'.")
	}

	field := args[2]

	if field == "Status" {
		invoice.Status = args[3]
	} else if field == "Statuscode" {
		invoice.Statuscode = args[3]
	} else if field == "DrawdownStatus" {
		invoice.DrawdownStatus = args[3]
	} else if field == "VendorAvailableLimit" {
		invoice.VendorAvailableLimit = args[3]
	} else if field == "AnchorAvailableLimit" {
		invoice.AnchorAvailableLimit = args[3]
	} else if field == "RepaymentDate" {
		invoice.RepaymentDate = args[3]
	} else if field == "RepaymentAmount" {
		invoice.RepaymentAmount = args[3]
	} else if field == "RepaymentStatus" {
		invoice.RepaymentStatus = args[3]
	} else if field == "MaturityDate" {
		invoice.MaturityDate = args[3]
	} else if field == "Tenure" {
		invoice.Tenure = args[3]
	} else if field == "InterestPayable" {
		invoice.InterestPayable = args[3]
	} else if field == "InterestRate" {
		invoice.InterestRate = args[3]
	} else if field == "PaymentStatus" {
		invoice.PaymentStatus = args[3]
	} else if field == "DrawdownRefNo" {
		invoice.DrawdownRefNo = args[3]
	} else if field == "UTR" {
		invoice.UTR = args[3]
	} else if field == "TransferType" {
		invoice.TransferType = args[3]
	} else if field == "VendorCustomerId" {
		invoice.VendorCustomerId = args[3]
	} else if field == "SupplierCode" {
		invoice.SupplierCode = args[3]
	} else if field == "AnchorCustomerId" {
		invoice.AnchorCustomerId = args[3]
	} else if field == "RequestReferenceNo" {
		invoice.RequestReferenceNo = args[3]
	} else if field == "InvoiceAmount" {
		invoice.InvoiceAmount = args[3]
	} else if field == "InvoiceDate" {
		invoice.InvoiceDate = args[3]
	} else if field == "InvoiceNumber" {
		invoice.InvoiceNumber = args[3]
	}

	//Owner  string `json:"Owner"`
	//Status string `json:"status"`
	// update the invoice field
	//invoice.field = args[3]
	bytes, err := json.Marshal(invoice)
	if err != nil {
		fmt.Printf("SAVE_CHANGES: Error converting InvoiceID record: %s", err)
		return shim.Error("Error converting InvoiceID record")
	}

	err = stub.PutState(invoice.InvoiceID, bytes)
	if err != nil {
		fmt.Printf("SAVE_CHANGES: Error storing  InvoiceID record: %s", err)
		return shim.Error("Error storing  InvoiceID record")
	}

	fmt.Println("- end update_invoice_field")
	return shim.Success(nil)
}

// ============================================================================================================================
// close_invoice() - remove a project from state and from project index
//
// Shows Off DelState() - "removing"" a key/value from the ledger
//
// Inputs - Array of strings
//      0      ,         1
//     id      ,  authed_by_company
// "m999999999", "united invoices"
// ============================================================================================================================
func close_invoice(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("starting close_invoice")

	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	// input sanitation
	err := sanitize_arguments(args)
	if err != nil {
		return shim.Error(err.Error())
	}

	id := args[1]
	//authed_by_company := args[2]

	// get the invoice
	invoice, err := get_invoice(stub, id)
	if err != nil {
		fmt.Println("Failed to find invoice by id " + id)
		return shim.Error(err.Error())
	}

	certname, err := get_cert(stub)
	if err != nil {
		fmt.Printf("INVOKE: Error retrieving cert: %s", err)
		return shim.Error("Error retrieving cert")
	}

	fndtn, err := get_lender(stub, string(certname))
	if err != nil {
		fmt.Println("Failed to find invoice by id " + id)
		return shim.Error(err.Error())
	}

	// check authorizing company (see note in set_owner() about how this is quirky)
	if invoice.Company != fndtn.AnchorCompany {
		return shim.Error("The company '" + fndtn.AnchorCompany + "' cannot authorize closure for '" + invoice.Company + "'.")
	}

	// update the invoice status
	invoice.Status = "Close invoice"

	bytes, err := json.Marshal(invoice)
	if err != nil {
		fmt.Printf("SAVE_CHANGES: Error converting invoice record: %s", err)
		return shim.Error("Error converting invoice record")
	}

	err = stub.PutState(invoice.InvoiceID, bytes)
	if err != nil {
		fmt.Printf("SAVE_CHANGES: Error storing  invoice record: %s", err)
		return shim.Error("Error storing invoice record")
	}

	fmt.Println("- end close_invoice")
	return shim.Success(nil)
}

//init_anchor===init_anchor
// ============================================================================================================================
// Init Lender - create a new lender aka end user, store into chaincode state
//
// Shows off building key's value from GoLang Structure
//
// Inputs - Array of Strings
//           0     ,     1   ,   2
//      lender id   , username, company
// "o9999999999999",     bob", "united projects"
// ============================================================================================================================
func init_anchor(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var err error
	fmt.Println("starting init_anchor")

	certname, err := get_cert(stub)
	if err != nil {
		fmt.Printf("INVOKE: Error retrieving cert: %s", err)
		return shim.Error("Error retrieving cert")
	}

	if len(args) != 3 {
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}

	//input sanitation
	err = sanitize_arguments(args)
	if err != nil {
		return shim.Error(err.Error())
	}

	var owner Anchor
	owner.ObjectType = "anchor"
	owner.AnchorID = string(certname)
	owner.AnchorUsername = args[1]
	owner.AnchorCompany = args[2]
	fmt.Println(owner)

	//check if user already exists
	_, err = get_lender(stub, owner.AnchorID)
	if err == nil {
		fmt.Println("This anchor userID already exists - " + owner.AnchorID)
		return shim.Error("This anchor userID already exists - " + owner.AnchorID)
	}

	//store user
	ownerAsBytes, _ := json.Marshal(owner)            //convert to array of bytes
	err = stub.PutState(owner.AnchorID, ownerAsBytes) //store owner by its Id
	if err != nil {
		fmt.Println("Could not store user")
		return shim.Error(err.Error())
	}

	fmt.Println("- end init_anchor project")
	return shim.Success(nil)
}

//init_invoice===init_invoice
//=================================================================================================================================
//	 Create Project - Creates the initial JSON for the Project and then saves it to the ledger.
//=================================================================================================================================
func init_invoice(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	certname, err := get_cert(stub)
	if err != nil {
		fmt.Printf("INVOKE: Error retrieving cert: %s", err)
		return shim.Error("Error retrieving cert")
	}

	b, err := get_lender(stub, string(certname))
	if err != nil {
		fmt.Printf("INVOKE: Error retrieving Buyer: %s", err)
		return shim.Error("Error retrieving Buyer")
	}

	anchorID := args[2]
	vendorID := args[4]
	invoiceNumber := args[7]
	var a MyBoxItem

	//inta, _ := strconv.Atoi(args[2])

	a.ObjectType = "invoice"
	a.InvoiceID = anchorID + vendorID + invoiceNumber
	a.RequestReferenceNo = args[1]
	a.AnchorCustomerId = args[2]
	a.SupplierCode = args[3]
	a.VendorCustomerId = args[4]
	a.TransferType = args[5]
	a.PaymentCurrency = args[6]

	a.InvoiceNumber = args[7]
	a.InvoiceDate = args[8]
	a.InvoiceAmount = args[9]

	a.UTR = args[10]
	a.DrawdownRefNo = args[11]
	a.PaymentStatus = args[12]
	a.InterestRate = args[13]
	a.InterestPayable = args[14]
	a.Tenure = args[15]
	a.MaturityDate = args[16]
	a.Company = b.AnchorCompany
	a.Owner = string(certname)
	a.Status = "CONST_INVOICE_CREATED"
	//a.Company = b.CompanyCompany

	if a.InvoiceID == "" { /*||
		matched == false */
		fmt.Printf("CREATE_INVOICE: Invalid InvoiceID provided")
		return shim.Error("Invalid InvoiceID provided")
	}

	record, err := stub.GetState(a.InvoiceID) // If not an error then a record exists so cant create a new order with this ID as it must be unique
	if record != nil {
		return shim.Error("InvoiceID already exists")
	}

	bytes, err := json.Marshal(a)
	if err != nil {
		fmt.Printf("SAVE_CHANGES: Error converting InvoiceID record: %s", err)
		return shim.Error("Error converting InvoiceID record")
	}

	err = stub.PutState(a.InvoiceID, bytes)
	if err != nil {
		fmt.Printf("SAVE_CHANGES: Error storing  InvoiceID record: %s", err)
		return shim.Error("Error storing  InvoiceID record")
	}

	fmt.Println("- end init_invoice")
	return shim.Success(nil)
}

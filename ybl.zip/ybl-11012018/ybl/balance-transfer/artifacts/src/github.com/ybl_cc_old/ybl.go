package main

import (
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

type SimpleChaincode struct {
}

//Bank===Bank
type Bank struct {
	ObjectType string `json:"docType"` //field for couchdb

	BankID       string `json:"bankId"`
	BankUsername string `json:"bankUsername"`
	BankCompany  string `json:"bankcompany"`
	LastTxn      Txn    `json:"lastTransaction"`
	//Donations    	 []DonorRelation `json:"donor"`
}

type Txn struct {
	ObjectType string `json:"docType"` //field for couchdb

	TxnStatus string  `json:"txnStatus"`
	TxnRefNo  string  `json:"txnRefNo"`
	Recepient string  `json:"recepient"`
	InvoiceID string  `json:"invoiceId"`
	Sender    string  `json:"sender"`
	TxnAmount float64 `json:"txnAmount"`
}

//MyBoxItem===Activity
type MyBoxItem struct {
	ObjectType string `json:"docType"` //field for couchdb

	InvoiceID       string `json:"InvoiceID"`
	PaymentCurrency string `json:"PaymentCurrency"`
	InvoiceNumber   string `json:"InvoiceNumber"`
	InvoiceDate     string `json:"InvoiceDate"`
	InvoiceAmount   string `json:"InvoiceAmount"`

	RequestReferenceNo string `json:"RequestReferenceNo"`
	AnchorCustomerId   string `json:"AnchorCustomerId"`
	SupplierCode       string `json:"SupplierCode"`
	VendorCustomerId   string `json:"VendorCustomerId"`
	TransferType       string `json:"TransferType"`
	UTR                string `json:"UTR"`
	DrawdownRefNo      string `json:"DrawdownRefNo"`
	PaymentStatus      string `json:"PaymentStatus"`
	InterestRate       string `json:"InterestRate"`
	InterestPayable    string `json:"InterestPayable"`
	Tenure             string `json:"Tenure"`
	MaturityDate       string `json:"MaturityDate"`
	RepaymentStatus    string `json:"RepaymentStatus"`

	RepaymentAmount      string `json:"RepaymentAmount"`
	RepaymentDate        string `json:"RepaymentDate"`
	AnchorAvailableLimit string `json:"AnchorAvailableLimit"`
	VendorAvailableLimit string `json:"VendorAvailableLimit"`
	DrawdownStatus       string `json:"DrawdownStatus"`
	Statuscode           string `json:"Statuscode"`
	Foundation           string `json:"Foundation"`

	Owner  string `json:"Owner"`
	Status string `json:"status"`
}

// ============================================================================================================================
// Main
// ============================================================================================================================
func main() {
	err := shim.Start(new(SimpleChaincode))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode - %s", err)
	}
}

// ============================================================================================================================
// Init - initialize the chaincode - projects don’t need anything initlization, so let's run a dead simple test instead
// ============================================================================================================================
func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("Projects Is Starting Up")
	_, args := stub.GetFunctionAndParameters()
	var Aval int
	var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	// convert numeric string to integer
	Aval, err = strconv.Atoi(args[0])
	if err != nil {
		return shim.Error("Expecting a numeric string argument to Init()")
	}

	// store compaitible projects application version
	err = stub.PutState("projects_ui", []byte("3.5.0"))
	if err != nil {
		return shim.Error(err.Error())
	}

	// this is a very simple dumb test.  let's write to the ledger and error on any errors
	err = stub.PutState("selftest", []byte(strconv.Itoa(Aval))) //making a test var "selftest", its handy to read this right away to test the network
	if err != nil {
		return shim.Error(err.Error()) //self-test fail
	}

	fmt.Println(" - ready for action") //self-test pass
	return shim.Success(nil)
}

// ============================================================================================================================
// Invoke - Our entry point for Invocations
// ============================================================================================================================
func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	fmt.Println(" ")
	fmt.Println("starting invoke, for - " + function)

	if function != "invoke" {
		return shim.Error("Unknown function call")
	}

	if len(args) < 2 {
		return shim.Error("Incorrect number of arguments. Expecting at least 2")
	}

	// Handle different functions
	if args[0] == "init" { //initialize the chaincode state, used as reset
		return t.Init(stub)
	} else if args[0] == "read" { //generic read ledger
		return read(stub, args)
	} else if args[0] == "write" { //generic writes to ledger
		return write(stub, args)
	} else if args[0] == "delete_invoice" { //deletes a project from state
		return delete_invoice(stub, args)
	} else if args[0] == "close_invoice" { //deletes a project from state
		return close_invoice(stub, args)
	} else if args[0] == "init_bank" { //create a new project donor
		return init_bank(stub, args)
	} else if args[0] == "init_invoice" { //create a new project donor
		return init_invoice(stub, args)
	} else if args[0] == "read_everything" { //read everything, (donors + projects + companies)
		return read_everything(stub)
	} else if args[0] == "getHistory" { //read history of a project (audit)
		return getHistory(stub, args)
	} else if args[0] == "getProjectsByRange" { //read a bunch of projects by start and stop id
		return getProjectsByRange(stub, args)
	} else if args[0] == "read_owner" { //read usercreds of a project (audit)
		return read_owner(stub, args)
	} else if args[0] == "update_invoice_field" { //create a new project donor
		return update_invoice_field(stub, args)
	} 

	// error out
	fmt.Println("Received unknown invoke function name - " + function)
	return shim.Error("Received unknown invoke function name - '" + function + "'")
}

// ============================================================================================================================
// Query - legacy function
// ============================================================================================================================
func (t *SimpleChaincode) Query(stub shim.ChaincodeStubInterface) pb.Response {
	return shim.Error("Unknown supported call - Query()")
}

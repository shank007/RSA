/*
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding  donorship.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
*/

package main

import (
	"bytes"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric/core/chaincode/shim"
)

/*
// ============================================================================================================================
// Get Donor - get the donor asset from ledger
// ============================================================================================================================
func get_owner(stub shim.ChaincodeStubInterface, id string) (Donor, error) {
	var donor Donor
	donorAsBytes, err := stub.GetState(id) //getState retreives a key/value from the ledger
	if err != nil {                        //this seems to always succeed, even if key didn't exist
		return donor, errors.New("Failed to get donor - " + id)
	}
	json.Unmarshal(donorAsBytes, &donor) //un stringify it aka JSON.parse()

	if len(donor.Username) == 0 { //test if donor is actually here or just nil
		return donor, errors.New("Donor does not exist - " + id + ", '" + donor.Username + "' '" + donor.Company + "'")
	}

	return donor, nil
}

// ============================================================================================================================
// Get Buyer - get the buyer asset from ledger
// ============================================================================================================================
func get_buyer(stub shim.ChaincodeStubInterface, id string) (Foundation, error) {
	var buyer Foundation
	buyerAsBytes, err := stub.GetState(id) //getState retreives a key/value from the ledger
	if err != nil {                        //this seems to always succeed, even if key didn't exist
		return buyer, errors.New("Failed to get buyer - " + id)
	}
	json.Unmarshal(buyerAsBytes, &buyer) //un stringify it aka JSON.parse()

	if len(buyer.FoundationUsername) == 0 { //test if buyer is actually here or just nil
		return buyer, errors.New("Foundation does not exist - " + id + ", '" + buyer.FoundationUsername + "' '" + buyer.FoundationCompany + "'")
	}

	return buyer, nil
}


// ============================================================================================================================
// Get ngo - get the seller asset from ledger
// ============================================================================================================================
func get_ngo(stub shim.ChaincodeStubInterface, id string) (NGO, error) {
	var seller NGO
	sellerAsBytes, err := stub.GetState(id) //getState retreives a key/value from the ledger
	if err != nil {                         //this seems to always succeed, even if key didn't exist
		return seller, errors.New("Failed to get seller - " + id)
	}
	json.Unmarshal(sellerAsBytes, &seller) //un stringify it aka JSON.parse()

	if len(seller.NGOUsername) == 0 { //test if seller is actually here or just nil
		return seller, errors.New("NGO does not exist - " + id + ", '" + seller.NGOUsername + "' '" + seller.NGOCompany + "'")
	}

	return seller, nil
}

// ========================================================
// Input JSON data - dumb input fetch from url indicataed by http://104.199.170.142:8000/project/Project8130263
// ========================================================
func fetchJson(stub shim.ChaincodeStubInterface, id string) (Asset, error) {

	// var asset Asset
	response, _ := http.Get("http://104.199.170.142:8000/project/" + id + "/")

	responseData, _ := ioutil.ReadAll(response.Body)

	var responseObject Asset
	json.Unmarshal(responseData, &responseObject)

	return responseObject, nil

}
*/
// ============================================================================================================================
// Get invoice - get a invoice asset from ledger
// ============================================================================================================================
func get_invoice(stub shim.ChaincodeStubInterface, id string) (MyBoxItem, error) {
	var invoice MyBoxItem
	invoiceAsBytes, err := stub.GetState(id) //getState retreives a key/value from the ledger
	if err != nil {                          //this seems to always succeed, even if key didn't exist
		return invoice, errors.New("Failed to find Invoice - " + id)
	}
	json.Unmarshal(invoiceAsBytes, &invoice) //un stringify it aka JSON.parse()

	if invoice.InvoiceID != id { //test if invoice is actually here or just nil
		return invoice, errors.New("Invoice does not exist - " + id)
	}

	return invoice, nil
}

// ============================================================================================================================
// Get Lender - get the lender asset from ledger
// ============================================================================================================================
func get_lender(stub shim.ChaincodeStubInterface, id string) (Bank, error) {
	var lender Bank
	lenderAsBytes, err := stub.GetState(id) //getState retreives a key/value from the ledger
	if err != nil {                         //this seems to always succeed, even if key didn't exist
		return lender, errors.New("Failed to get lender - " + id)
	}
	json.Unmarshal(lenderAsBytes, &lender) //un stringify it aka JSON.parse()

	if len(lender.BankUsername) == 0 { //test if lender is actually here or just nil
		return lender, errors.New("Bank does not exist - " + id + ", '" + lender.BankUsername + "' '" + lender.BankCompany + "'")
	}

	return lender, nil
}

// ============================================================================================================================
// Get User Certificate Common Name - get the seller asset from ledger
// ============================================================================================================================
func get_cert(stub shim.ChaincodeStubInterface) ([]byte, error) {

	creator, err := stub.GetCreator() //get the var from ledger
	if err != nil {
		//jsonResp = "{\"Error\":\"Failed to get state for " + key + "\"}"
		return creator, errors.New("blah!")
	}

	certStart := bytes.IndexAny(creator, "----BEGIN CERTIFICATE-----")
	if certStart == -1 {
		//logger.Debug("No certificate found")
		return creator, errors.New("No certificate found!")
	}
	certText := creator[certStart:]
	block, _ := pem.Decode(certText)
	if block == nil {
		//logger.Debug("Error received on pem.Decode of certificate",  certText)
		return creator, errors.New("Error received on pem.Decode of certificate")
	}

	ucert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		//logger.Debug("Error received on ParseCertificate", err)
		return creator, errors.New("Error received on ParseCertificate")
	}

	//logger.Debug("Common Name", ucert.Subject.CommonName)

	fmt.Println([]byte(ucert.Subject.CommonName))
	fmt.Println("- end read")
	//return shim.Success(creator) //send it onward
	return []byte(ucert.Subject.CommonName), nil //send it onward
}

// =========================================================================================
// getQueryResultForQueryString executes the passed in query string.
// Result set is built and returned as a byte array containing the JSON results.
// =========================================================================================
func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil
}

// ========================================================
// Input Sanitation - dumb input checking, look for empty strings
// ========================================================
func sanitize_arguments(strs []string) error {
	for i, val := range strs {
		if len(val) <= 0 {
			return errors.New("Argument " + strconv.Itoa(i) + " must be a non-empty string")
		}
		if len(val) > 32 {
			return errors.New("Argument " + strconv.Itoa(i) + " must be <= 32 characters")
		}
	}
	return nil
}
